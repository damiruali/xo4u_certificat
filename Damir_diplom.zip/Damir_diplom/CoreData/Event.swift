//
//  Event.swift
//  Damir_diplom
//
//  Created by Дамир Уали on 29.05.2024.
//

import Foundation

import CoreData

@objc(Event)
public class Event: NSManagedObject {
    @NSManaged public var title: String
    @NSManaged public var startDate: Date
    @NSManaged public var endDate: Date
    @NSManaged public var eventDescription: String
    @NSManaged public var participants: [String]
}

