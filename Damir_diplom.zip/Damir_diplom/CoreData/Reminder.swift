//
//  Reminder.swift
//  Damir_diplom
//
//  Created by Дамир Уали on 29.05.2024.
//

import Foundation

import CoreData

@objc(Reminder)
public class Reminder: NSManagedObject {
    @NSManaged public var title: String
    @NSManaged public var date: Date
    @NSManaged public var reminderDescription: String
}
