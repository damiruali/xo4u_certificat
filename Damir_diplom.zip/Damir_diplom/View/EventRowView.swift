//
//  EventRowView.swift
//  Damir_diplom
//
//  Created by Дамир Уали on 29.05.2024.
//

import Foundation
