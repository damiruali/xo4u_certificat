//
//  ReminderListView.swift
//  Damir_diplom
//
//  Created by Дамир Уали on 29.05.2024.
//

import Foundation
import SwiftUI
import CoreData

struct ReminderListView: View {
    @FetchRequest(
        entity: Reminder.entity(),
        sortDescriptors: [NSSortDescriptor(keyPath: \Reminder.date, ascending: true)]
    ) var reminders: FetchedResults<Reminder>
    @Environment(\.managedObjectContext) private var viewContext

    var body: some View {
        NavigationView {
            List {
                ForEach(reminders) { reminder in
                    ReminderRowView(reminder: reminder)
                }
                .onDelete { indexSet in
                    for index in indexSet {
                        let reminder = reminders[index]
                        viewContext.delete(reminder)
                    }
                    try? viewContext.save()
                }
            }
            .navigationTitle("Reminders")
            .navigationBarItems(trailing: NavigationLink("Add Reminder", destination: AddReminderView()))
        }
    }
}

struct ReminderRowView: View {
    @ObservedObject var reminder: Reminder

    var body: some View {
        VStack(alignment: .leading) {
            Text(reminder.title ?? "No Title")
                .font(.headline)
            Text("\(reminder.date ?? Date())")
                .font(.subheadline)
        }
    }
}
