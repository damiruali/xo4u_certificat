//
//  EventListView.swift
//  Damir_diplom
//
//  Created by Дамир Уали on 29.05.2024.
//

import Foundation

import SwiftUI
import CoreData

struct EventListView: View {
    @FetchRequest(
        entity: Event.entity(),
        sortDescriptors: [NSSortDescriptor(keyPath: \Event.startDate, ascending: true)]
    ) var events: FetchedResults<Event>
    @Environment(\.managedObjectContext) private var viewContext

    var body: some View {
        NavigationView {
            List {
                ForEach(events) { event in
                    EventRowView(event: event)
                }
                .onDelete { indexSet in
                    for index in indexSet {
                        let event = events[index]
                        viewContext.delete(event)
                    }
                    try? viewContext.save()
                }
            }
            .navigationTitle("Events")
            .navigationBarItems(trailing: NavigationLink("Add Event", destination: AddEventView()))
        }
    }
}

struct EventRowView: View {
    @ObservedObject var event: Event

    var body: some View {
        VStack(alignment: .leading) {
            Text(event.title ?? "No Title")
                .font(.headline)
            Text("\(event.startDate ?? Date()) - \(event.endDate ?? Date())")
                .font(.subheadline)
        }
    }
}
