//
//  AddReminderView.swift
//  Damir_diplom
//
//  Created by Дамир Уали on 29.05.2024.
//

import Foundation
import SwiftUI
import CoreData

struct AddReminderView: View {
    @Environment(\.managedObjectContext) private var viewContext
    @State private var title = ""
    @State private var date = Date()
    @State private var description = ""

    var body: some View {
        Form {
            Section(header: Text("Reminder Details")) {
                TextField("Title", text: $title)
                DatePicker("Date", selection: $date)
                TextField("Description", text: $description)
            }

            Button("Save") {
                let newReminder = Reminder(context: viewContext)
                newReminder.title = title
                newReminder.date = date
                newReminder.reminderDescription = description
                try? viewContext.save()
            }
        }
        .navigationTitle("Add Reminder")
    }
}
