//
//  AddEventView.swift
//  Damir_diplom
//
//  Created by Дамир Уали on 29.05.2024.
//

import Foundation
import SwiftUI
import CoreData

struct AddEventView: View {
    @Environment(\.managedObjectContext) private var viewContext
    @State private var title = ""
    @State private var startDate = Date()
    @State private var endDate = Date()
    @State private var description = ""

    var body: some View {
        Form {
            Section(header: Text("Event Details")) {
                TextField("Title", text: $title)
                DatePicker("Start Date", selection: $startDate)
                DatePicker("End Date", selection: $endDate)
                TextField("Description", text: $description)
            }

            Button("Save") {
                let newEvent = Event(context: viewContext)
                newEvent.title = title
                newEvent.startDate = startDate
                newEvent.endDate = endDate
                newEvent.eventDescription = description
                newEvent.participants = []
                try? viewContext.save()
            }
        }
        .navigationTitle("Add Event")
    }
}
