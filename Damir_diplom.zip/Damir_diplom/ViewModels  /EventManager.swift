//
//  EventManager.swift
//  Damir_diplom
//
//  Created by Дамир Уали on 29.05.2024.
//

import Foundation

import CoreData

class EventManager {
    private let context = PersistenceController.shared.context

    func createEvent(title: String, startDate: Date, endDate: Date, description: String, participants: [String]) {
        let newEvent = Event(context: context)
        newEvent.title = title
        newEvent.startDate = startDate
        newEvent.endDate = endDate
        newEvent.eventDescription = description
        newEvent.participants = participants
        saveContext()
    }

    func getEvents() -> [Event] {
        let request: NSFetchRequest<Event> = Event.fetchRequest()
        do {
            return try context.fetch(request)
        } catch {
            print("Failed to fetch events: \(error)")
            return []
        }
    }

    func updateEvent(event: Event, title: String, startDate: Date, endDate: Date, description: String, participants: [String]) {
        event.title = title
        event.startDate = startDate
        event.endDate = endDate
        event.eventDescription = description
        event.participants = participants
        saveContext()
    }

    func deleteEvent(event: Event) {
        context.delete(event)
        saveContext()
    }

    private func saveContext() {
        do {
            try context.save()
        } catch {
            print("Failed to save context: \(error)")
        }
    }
}
