//
//  ReminderManager.swift
//  Damir_diplom
//
//  Created by Дамир Уали on 29.05.2024.
//

import Foundation

import CoreData

class ReminderManager {
    private let context = PersistenceController.shared.context

    func createReminder(title: String, date: Date, description: String) {
        let newReminder = Reminder(context: context)
        newReminder.title = title
        newReminder.date = date
        newReminder.reminderDescription = description
        saveContext()
    }

    func getReminders() -> [Reminder] {
        let request: NSFetchRequest<Reminder> = Reminder.fetchRequest()
        do {
            return try context.fetch(request)
        } catch {
            print("Failed to fetch reminders: \(error)")
            return []
        }
    }

    func updateReminder(reminder: Reminder, title: String, date: Date, description: String) {
        reminder.title = title
        reminder.date = date
        reminder.reminderDescription = description
        saveContext()
    }

    func deleteReminder(reminder: Reminder) {
        context.delete(reminder)
        saveContext()
    }

    private func saveContext() {
        do {
            try context.save()
        } catch {
            print("Failed to save context: \(error)")
        }
    }
}
