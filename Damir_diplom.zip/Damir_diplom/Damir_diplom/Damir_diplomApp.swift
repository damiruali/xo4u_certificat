//
//  Damir_diplomApp.swift
//  Damir_diplom
//
//  Created by Дамир Уали on 28.05.2024.
//

import SwiftUI

@main
struct Damir_diplomApp: App {
    let persistenceController = PersistenceController.shared

    var body: some Scene {
        WindowGroup {
            ContentView()
                .environment(\.managedObjectContext, persistenceController.container.viewContext)
        }
    }
}
